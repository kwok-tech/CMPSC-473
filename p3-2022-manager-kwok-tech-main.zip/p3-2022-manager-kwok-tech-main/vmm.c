#include "vmm.h"

// Memory Manager implementation
// Implement all other functions here...


int fifo(int startAd) {
    /*Evict the oldest virtual page (among the currently resident pages in physical memory)
    brought in to the physical memory. You will have to protect the pages that are NOT in 
    physical memory to catch accesses to these page and record page faults.*/
    //assert("FIFO Replacement Policy not implemented");

    int i;
    //struct frame evictedFrame = frames[0];

    // save frame[0]
    int oldStart = frames[0].startAd;
    int oldPage = frames[0].pageNum;
    int oldPhys = frames[0].physAd;

    writeback = frames[0].isWritten;

    //reset premissions
    if(mprotect(vMem + frames[0].startAd, pageSize, PROT_NONE) == -1) {
        // handle error
        perror("mprotect PROT_NONE 2");
    }

    // shift array towards zero by 1
    for(i = 1; i < numFrames; i++) {
        frames[i-1].startAd = frames[i].startAd;
        frames[i-1].pageNum = frames[i].pageNum;
        frames[i-1].physAd = frames[i].physAd;
        frames[i-1].isWritten = frames[i].isWritten;
    }

    // insert new frame at end of array 
    frames[numFrames - 1].startAd = startAd;
    frames[numFrames - 1].pageNum = oldPage;

    if(faultType == 1) {
        frames[numFrames-1].isWritten = true;
    } else {
        frames[numFrames-1].isWritten = false;
    }


    return oldStart/pageSize;
    
}

int tc(int startAd) {
    
    int highestIndex;
    int highest = -1;
    //struct frame evictedFrame = frames[0];

    // find the frame to be evicted
    int i;
    for(i = 0; i < numFrames; i++) {
        // check for lowest use count by fifo
        if(frames[i].useCount > highest) {
            highest = frames[i].useCount;
            highestIndex = i;
        }
    }

    if(highest < 3) {
        for(i = 0; i < numFrames; i++) {
             frames[i].useCount += (3 - highest);   
        }
    }
    
    // save evicted frame
    int oldStart = frames[highestIndex].startAd;
    int oldPage = frames[highestIndex].pageNum;
    int oldPhys = frames[highestIndex].physAd;
    int oldCount = frames[highestIndex].useCount;
    writeback = frames[highestIndex].isWritten;

    //reset premissions
    if(mprotect(vMem + frames[highestIndex].startAd, pageSize, PROT_NONE) == -1) {
        // handle error
        perror("mprotect PROT_NONE 3");
    }

    // insert new frame evicted frame 
    frames[highestIndex].startAd = startAd;
    frames[highestIndex].useCount = 1;

    if(faultType == 1) {
        frames[highestIndex].isWritten = true;
    } else {
        frames[highestIndex].isWritten = false;
    }

    return oldStart/pageSize;

}














