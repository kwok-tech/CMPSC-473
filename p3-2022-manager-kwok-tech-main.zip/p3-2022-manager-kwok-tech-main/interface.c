#include "interface.h"
#include "vmm.h"

// Interface implementation
//global vars




// Implement APIs here...
void mm_init(enum policy_type policy, void *vm, int vm_size, int num_frames, int page_size)
{
    //save all param as global vars
    globalPolicy = (int)policy;
    vmSize = vm_size;
    numFrames = num_frames;
    pageSize = page_size;
    pageCount = 0;
    faultType = -1;
    struct page *pages = (struct page*) malloc(vmSize/pageSize * sizeof(struct page));
    frames = (struct frame*) malloc(numFrames * sizeof(struct frame));
    //init virtual memory
    vmArr = (struct page*) malloc(vmSize/pageSize * sizeof(struct page));
    int i;
    
    for (i=0; i<vmSize/pageSize; i++) {
        // initiallize page variables
        pages[i].startAd = pageSize*i;
        pages[i].isWritten = false;
    } 
    
    //init frame array
    for (i = 0; i < numFrames; i++) {
            frames[i].startAd = -1;
            frames[i].pageNum = i;
            frames[i].physAd = pageSize*i;
            frames[i].isWritten = false;
            frames[i].useCount = 0;
            printf("Frame:%d = %d\n", i, (frames[i].startAd));
    }
    vmArr = pages;
    vMem = vm;
    faultPage = (void *) malloc(sizeof(vMem));
    
    // create the sigaction and set handler and flags 
    struct sigaction sa;
    sa.sa_handler = segHandler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);

    int sigResult = sigaction(SIGSEGV, &sa, NULL);
    if(sigResult == -1) {
        perror("error in sigaction");
        exit(EXIT_FAILURE);
    }
    // Initiallize vm array to PROT_NONE
    if(mprotect(vm, vmSize, PROT_NONE) == -1) {
        // handle error
        perror("mprotect PROT_NONE 1");
    }
}



void segHandler(int sig, siginfo_t *info, ucontext_t *ucontext) {
    //1. int sig :: https://man7.org/linux/man-pages/man2/sigaction.2.html,
    //2. siginfo_t *info :: https://www.mkssoftware.com/docs/man5/siginfo_t.5.asp,
    //3. void *ucontext :: https://nxmnpg.lemoda.net/3/ucontext#:~:text=The%20ucontext_t%20type%20is%20a,and%20list%20of%20blocked%20signals.&text=The%20uc_link%20field%20points%20to,context%27s%20entry%20point%20function%20returns.
    int fPage, fFrame, evictedVirtPage = -1;
    //  the address of the access that raised the fault
    void * faultAddress = info->si_addr;
    faultPage = vMem;
   
    // find page the fault occurred on
    if(faultPage == faultAddress) {
        faultPage = faultAddress;
    } else {
        while(faultPage+pageSize <= faultAddress) {
            faultPage += pageSize;
        }
    }
    //virtual Addr of fault in frame
    int startAddr = (int)faultPage-(int)vMem;  
    
    // whether the fault raised originated from a read operation or a write operation.
    //int faultType;  //SIGSEGV fault type (read: 0 write: 1)
    if (ucontext->uc_mcontext.gregs[REG_ERR] & 0x2) {
        // Write fault
        faultType = 1;
    } else {
        // Read fault
        faultType = 0;
    }
    int i;
    //check if frame already exists
    for (i=0; i<numFrames; i++) {
        if (frames[i].startAd == startAddr) {
            if(!frames[i].isWritten && faultType == 1) {
                faultType = 2;
            }

            // saving current frame
            currentFrame = i;
            frames[currentFrame].useCount++;

            // accessed frame, iterate counter
            frames[currentFrame].useCount ++;
        }
    }


    //find current page
    fPage = startAddr/pageSize;
    //insertion if faultType is 1 or 0
    if (faultType == 0 || faultType == 1) {
        // fill frame with this page according to eviction policy
        if (pageCount < numFrames) {
            // insert into frames array
            int k = 0;
            //go to empty slot
            while(frames[k].startAd!= -1 && k <= numFrames) {
                k++;
            }
            currentFrame = k;
            frames[k].startAd = startAddr;

            // first access, set counter to 1
            frames[currentFrame].useCount ++;

            //fault is write
            if(faultType == 1) {
                    frames[currentFrame].isWritten = true;
            }

        } else {
            // frames are full, eviction policy check
            currentFrame = numFrames-1;
            if (globalPolicy == MM_FIFO) {
                evictedVirtPage = fifo(startAddr);
                
            }
            if (globalPolicy == MM_THIRD) {
                evictedVirtPage = tc(startAddr);

            }
            //page removed
            pageCount--;
        }
        //page counter will always increase for frames filled
        pageCount++;

        //calulate physical Address
        physAddr =(unsigned int)(faultAddress-faultPage) + pageSize*frames[currentFrame].pageNum;
        frames[currentFrame].physAd = physAddr;
    }
    
    //set permissions
    if (faultType == 1) {
        //write to page in vm
        //find frame 
        if(mprotect(faultPage, pageSize, PROT_READ | PROT_WRITE) == -1) {
            // handle error
            perror("mprotect PROT_WRITE");
        }
    } else if (faultType == 2) {
        //find frame and add write permissions to read-only
        frames[currentFrame].isWritten = true;
        physAddr = (unsigned int)(faultAddress-faultPage) + pageSize*frames[currentFrame].pageNum;
        writeback = 0;
        if(mprotect(faultPage, pageSize, PROT_WRITE) == -1) {
            // handle error
            perror("mprotect PROT_WRITE");
        }
    } else {
        //printf("faultPage%p/n", faultPage);
        //read to page in vm
        //frames[numFrames-1].isWritten = false;
        if(mprotect(faultPage, pageSize, PROT_READ) == -1) {
            // handle error
            perror("mprotect PROT_READ");
        }
        
    }
    
    
    //printf("Virtual Page: %d Fault: %d, Fault Addr: %d",fPage, faultType, (unsigned int)faultAddress);
    mm_logger(fPage, faultType, evictedVirtPage, writeback, physAddr);
}
