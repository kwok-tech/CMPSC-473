#ifndef VMM_H
#define VMM_H

#include "interface.h"

// Declare your own data structures and functions here...
//data structure
struct frame {
    int startAd;
    int pageNum;
    int physAd;
    int useCount;
    bool isWritten;
}frame;

struct page {
    int startAd;
    bool isWritten;
    //void * physAd;
}page;

static struct page *vmArr;
struct frame *frames;
void * faultPage;
void * vMem;
unsigned int physAddr;
int pageSize, vmSize, globalPolicy;
int numFrames, pageCount, currentFrame;
int writeback, faultType;

//Policy Functions
int fifo(int startAd);   //First In First Out Replacement Policy
int tc(int startAd);     //Third Chance Replacement Policy


#endif
