#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <limits.h>
#include <pthread.h>
#include "interface.h"

#define TRUE 1
#define FALSE 0

//global vars
int globalTime;//global time
pthread_mutex_t mutex; //thread mutex lock
int MAXTHREADS;//maximum number of threads

//storing thread info
typedef struct threadInfo {
  int tid; //thread id
  pthread_cond_t cond;//thread conditional for blocking
  float  arrivalTime; //thread arrival time
  int remainTime; //thread remaining time
  int currTime; //thread current time
  
}threadInfo;

//node for queue
typedef struct Node_t {
    threadInfo data;
    struct Node_t *next;
} NODE;

//queue structure (need one for cpu and io operations)
typedef struct Queue{
  //queue struct
  NODE *head;
  NODE *tail;
  int max;
  int size;
}Queue;

//global list structures
Queue * CPU_Queue;
Queue * IO_Queue;
threadInfo *threads;

//queue functions
Queue *createQueue(int max);
void *destroyQueue(Queue *queue);
int enqueue(Queue *queue, NODE *item);
NODE *dequeue(Queue *queue);
int isEmpty(Queue *queue);
Queue *copyQueue(Queue *queue);

//scheduling policies
//first come first serve (IO scheduling policy)
void fcfs();
//shortest remaining time first
void srtf();
//multi-level feedback queue
void mlfq();









#endif
