#include "scheduler.h"

// Scheduler implementation
// Implement all other functions here...

// queue functions
Queue *createQueue(int max)
{
  // allocate space for queue
  Queue *queue = (Queue *)malloc(sizeof(Queue));
  if (queue != NULL)
  {
    if (max <= 0)
    {
      max = 65535;
    }

    queue->max = max;
    queue->size = 0;
    queue->head = NULL;
    queue->tail = NULL;

    return queue;
  }

  return NULL;
}

void *destroyQueue(Queue *queue)
{
  NODE *pN;
  while (!isEmpty(queue))
  {
    pN = dequeue(queue);
    free(pN);
  }
  free(queue);
}

// add new node to queue
int enqueue(Queue *queue, NODE *item)
{
  // Bad parameter
  if ((queue == NULL) || (item == NULL))
  {
    printf("False");
    return FALSE;
  }
  if (queue->max != 0)
    if (queue->size >= queue->max)
    {
      printf("False");
      return FALSE;
    }
  // set next to null
  item->next = NULL;

  // the queue is empty
  if (queue->max == 0)
  {
    queue->head = item;
    queue->tail = item;
  }
  else
  {
    // allocate space
    queue->tail = (NODE *)malloc(sizeof(NODE));
    // adding item to the end of the queue
    queue->tail->next = item;
    queue->tail = item;
  }
  queue->max++;
  return TRUE;
}

// removes node from queue
NODE *dequeue(Queue *queue)
{
  // the queue is empty or bad param
  NODE *item;
  if (isEmpty(queue))
    return NULL;
  item = queue->head;
  queue->head = (queue->head)->next;
  queue->size--;
  // returns node that was dequeued
  return item;
}

// helper function for queue, check if queue is empty
int isEmpty(Queue *queue)
{
  if (queue == NULL)
  {
    return FALSE;
  }
  if (queue->size == 0)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}

// returns deep copy of queue
Queue *copyQueue(Queue *queue)
{
  Queue *cQ = createQueue(queue->max);
  NODE *element; // element from queue to iterate
  for (element = queue->head; element; element = element->next)
  {
    enqueue(cQ, element);
  }
  return cQ;
}

void fcfs()
{
  int i, j;   // increment
  int lowest; // track lowest arrival
  int fTid;   // track lowest arrival's thread id, first thread acted upon

  // loop and sort
  for (i = 0; i < MAXTHREADS; i++)
  {
    lowest = threads[i].arrivalTime; // returns element on position
    fTid = threads[i].tid;           // index of that element
    for (j = i + 1; j < MAXTHREADS; j++)
    {
      // if empty move backwards
      if (threads[i].arrivalTime == -1)
      {
        // swap
        threadInfo temp = threads[j];
        threads[j] = threads[i];
        threads[i] = temp;
      }
      // check the arrival times
      else if (threads[j].arrivalTime < lowest)
      {
        fTid = threads[j].tid;
        lowest = threads[j].arrivalTime;
        // swap
        threadInfo temp = threads[j];
        threads[j] = threads[i];
        threads[i] = temp;
      }
      // if arrive at same time
      else if (threads[i].arrivalTime == lowest)
      {
        // check which has lower thread id
        if (threads[i].tid < fTid)
        {
          lowest = threads[i].arrivalTime;
          fTid = threads[i].tid;
          // swap
          threadInfo temp = threads[j];
          threads[j] = threads[i];
          threads[i] = temp;
          // insert item into queue
          // NODE *item;
          // item = (NODE *)malloc(sizeof(NODE));
          // item->data = threads[fTid];
          // enqueue(CPU_Queue, item);
        }
      }
    }
  }
  // create deep copy of CPU queue
  //  Queue *pQ = copyQueue(CPU_Queue);
  /*
  while (!isEmpty(CPU_Queue))
  {
    NODE *pN = dequeue(CPU_Queue);
    // blocking all threads
    pthread_cond_signal(&(CPU_Queue->head->data.cond));
    // unblock lowest arrival time first
    if (CPU_Queue->head->data.tid == fTid)
    {
      // update queue
      pthread_cond_wait(&CPU_Queue->head->data.cond, &mutex);
      CPU_Queue->head->data.remainTime = CPU_Queue->head->data.remainTime - 1;
    }
    // iterate to next in queue
    free(pN);

  }
  */
  /*for (i = 0; i < MAXTHREADS; i++)
  {
    // blocking all threads
    pthread_cond_wait(&threads[i].cond, &mutex);
    // unblock lowest arrival time first
    if (threads[i].tid == fTid)
    {
      // update array
      pthread_cond_signal(&threads[i].cond);
      threads[i].remainTime--;
    }
  }
  for (i = 0; i < MAXTHREADS; i++)
  {
    pthread_cond_broadcast(&threads[i].cond);
  }
  */
}

/*void srtf()
{
  // based on each remaining time, whichever has the lowest, that thread will go first
}
*/
