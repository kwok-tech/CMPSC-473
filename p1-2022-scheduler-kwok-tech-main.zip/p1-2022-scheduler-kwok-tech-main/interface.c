#include "interface.h"
#include "scheduler.h"

// Interface implementation
// Implement APIs here...

int globalType;

// This is invoked once in the beginning. You can initialize anything you may want here
void init_scheduler(enum sch_type type, int thread_count)
{
  int i; // increment
  // set scheduler type
  globalType = type;
  // set maximum threads
  MAXTHREADS = thread_count;
  // create array of threads
  threads = (threadInfo *) malloc(MAXTHREADS * sizeof(threadInfo));
  for (i = 0; i < thread_count; i++)
  {
    threads[i].tid = -1;
    threads[i].arrivalTime = -1;
    threads[i].remainTime = -1;
    threads[i].currTime = -1;
  }
  // initilize the locks
    //pthread_mutex_init(&mutex, NULL);
  // makes info global to be accessed anywhere
  
  // init queues
  CPU_Queue = createQueue(thread_count);
  // IO_Queue = createQueue(thread_count);
}

// return from function if the calling thread should run on the CPU for at least the next tick.
// The thread will then subsequently come back and call this function for the remaining time in the burst.  (i.e. 1 tick less than the previous call).
int cpu_me(float current_time, int tid, int remaining_time)
{
  int i;             // increment
  bool isIn = false; // checks if thread in array
  // create locks
  //pthread_mutex_lock(&mutex);
  // find thread
  for (i = 0; i < MAXTHREADS; i++)
  {
    // setting thread info
    if (threads[i].tid == tid)
    {
      threads[i].remainTime = remaining_time;
      threads[i].currTime = current_time;
      //found
      isIn = true;
      break;
    }
  }
  // thread not in array already
  if (isIn == false)
  {
    for (i = 0; i < MAXTHREADS; i++)
    {
      //find empty thread
      if (threads[i].tid == -1)
      {
        // if thread dne yet
        threads[i].tid = tid;
        threads[i].arrivalTime = current_time;
        threads[i].remainTime = remaining_time;
        threads[i].currTime = current_time;
        break;
      }
    }
  }
  // pick schedule (need to find perform time-sharing context switching)
   if (globalType == 0) {
   fcfs();
  }
  // if (globalType == 1) {
  // srtf();
  // }
  // if (globalType == 2) {
  // mlfq();
  //}
  // unlock thread
 //pthread_mutex_unlock(&mutex);
  // Return value: the time when the thread has completed 1 tick of execution on the CPU.
  // Note that this may not necessarily be 1 more than the time that it was called with - depends on whether some other thread will get to execute on the CPU in-between.

  // check remaining time
  if (threads[tid].remainTime == 0)
  {
    return 0;
  }
  globalTime = ceil(current_time);
  globalTime++;
  return globalTime;
}

// This function must return only when the whole IO duration is finished.
// Note that it is possible that the IO device is busy when this call is made, in which case the request should get serviced only after all prior IO requests are serviced.
int io_me(float current_time, int tid, int duration)
{
  // batching

  // Return value: the time IO completely finishes and returns
}

// P implements the WAIT operation for the semaphore identified by sem_id
// This may be a blocking call, according to the semaphore definition
int P(float current_time, int tid, int sem_id)
{
  // Return value: the time it returns
}

// V implements the SIGNAL operation for the semaphore identified by sem_id
// If more than 1 thread is blocked on the same sem_id, the thread with the lowest tid will return from P()
int V(float current_time, int tid, int sem_id)
{
  // Return value: the time it returns
}

// Notify your scheduler that the calling thread tid is terminating.
void end_me(int tid)
{
  // pthread_mutex_destroy(&mutex);
  // destroyQueue(CPU_Queue);
  // destroyQueue(IO_Queue);
  // free(threads);
}
