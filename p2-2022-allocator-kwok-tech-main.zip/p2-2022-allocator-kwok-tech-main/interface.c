#include "interface.h"
#include "my_memory.h"

// Interface implementation
// Implement APIs here...


void my_setup(enum malloc_type type, int mem_size, void *start_of_memory)
{

    //printf("\n%d\n%d\n%p", type, mem_size, start_of_memory);
    globalType = type;
    globalMemSize = mem_size;
    globalStartOfMemory = start_of_memory;
    globalAvailMemory = MEMORY_SIZE;

    // Allocate space for Free list
    mainMem = (struct Node*)malloc(sizeof(struct Node)* globalMemSize);

    //initiallize the first node in mainMem
    mainMem->startAdd = 0;
    //mainMem->endAdd = mem_size;
    mainMem->size = mem_size;
    mainMem->buddyNum = mem_size;
    mainMem->isFree = 1;
    mainMem->next = NULL;
    int i;
    for(i = 0; i < 15; i++) {
        mainMem->oldBudNums[i] = -1;
    }
    currentFree = mainMem;
    printf("\n\n\n\n\n");
}

void *my_malloc(int size)
{
    if (globalType==MALLOC_BUDDY) {
        // BUDDY
        if(globalAvailMemory < size) {
            return NULL;
        }
        return globalStartOfMemory + malloc_buddy(size) + HEADER_SIZE;
        
    } else {
        // SLAB
        return malloc_slab(size) + HEADER_SIZE;
    }
}

void my_free(void *ptr)
{
    // add back to globalAvailMemory
    if (globalType==MALLOC_BUDDY) {
        // BUDDY
        free_buddy(ptr);
    } else {
        // SLAB
    //     free_slab(ptr);
    }
}
