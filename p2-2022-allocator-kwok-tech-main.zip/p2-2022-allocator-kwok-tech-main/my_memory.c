#include "my_memory.h"

// Memory allocator implementation
// Implement all other functions here...

// Helper Functions
int malloc_buddy(int request) {
    /*
    
    if mainMem is null 
        // this won't happen since we initiallized mainMem in my_setup
    if mainMem is not null
        first find the smallest node (node->size=endaddress-startaddress) 
        if two smallest nodes exist, select the one with the lowest startAddress
        if node->size is smaller than the request, find next smallest node
        repeat until smallest node that can fit request is found.
        check if node can be split in half and still fit request
        if not {
            set isFree to 0
            return node->startAddress
        } else {

            while(node can be split) {
                create a new buddy pair
                    buddyID for both nodes/pairs = endaddress/2; this is how we know which nodes are "buddies/pairs for freeing later"
                check if node can be split in half and still fit request
            }
            move node from mainMem to memUsed
            return node->startAddress
        }

    */
   //rounds request to correct power of 2 partition size
    int roundedReq = nextPowerOf2(request);
    request=roundedReq;
    // set smallest to first non-used node initially
    struct Node* smallestPartition = mainMem;
    //parse and seach for first free partition
    while(smallestPartition->isFree == 0) {
        smallestPartition = smallestPartition->next;
    }
    int smallest = smallestPartition->size;         //tracks smallest size
    int smallestID = smallestPartition->startAdd;   //tracks smallest's address
    //printf("\nsmallestID = smallestPartition->startAdd=%d", smallestID);
    // Find list size and smallest (valid i.e. can fit req) node
    if(mainMem->next == NULL) { // its the only link in the list i.e. no buddy splits have been done yet
        // DO NOTHING
    } else {                    // iterate through and count the links
        while(smallestPartition != NULL) {
            //printf("\ntempsize: %d\nsmallest: %d\nisfree: %d\n", smallestPartition->size, smallest, smallestPartition->isFree);
            //printf("StartAddress + Size = EndAddress : %d + %d = %d", smallestPartition->startAdd, smallestPartition->size, smallestPartition->startAdd + smallestPartition->size );
            if (smallestPartition->isFree == 1 &&  smallestPartition->size <= request) {
                smallest = smallestPartition->size;
                smallestID = smallestPartition->startAdd;
            }
            smallestPartition = smallestPartition->next;
        }
        
    }
    // grab smallest node once its ID has been found
    smallestPartition = findNode(smallestID);
    //printf("\n%d\n%d\n", smallestPartition->startAdd, smallestPartition->size);
    
    // check if node can be cut in half and still fit
    while(smallestPartition->size/2 >= request) {
        int tempBud = smallestPartition->startAdd + smallestPartition->size/2;
        //split nodes
        addNode(smallestPartition->startAdd, smallestPartition->size/2, tempBud, 0); 
        editNode(smallestPartition, smallestPartition->startAdd+(smallestPartition->size/2), smallestPartition->size/2, tempBud, 1);
        //store prev buddy num to oldBudNums array
        int i = 0;
        while(i < 15 && smallestPartition->oldBudNums[i] != -1  ) {
            i++;
        }
        smallestPartition->oldBudNums[i] = tempBud;

        for(i = 0; i < 15; i++) {
            mainMem->oldBudNums[i] = smallestPartition->oldBudNums[i];
        }
        mainMem->oldBudNums[i] = tempBud;

        int x;
        for(x = 0; x < 15; x++) {
            printf("\nLOWER_BUDDY_NUMS[%d]: %d\nUPPER_BUDDY_NUMS[%d]: %d\n", x, smallestPartition->oldBudNums[x], x, mainMem->oldBudNums[x]);
        }
        smallestPartition = mainMem;

        
    }
    
    // at this point, we have found the smallest valid location and it is the node "smallestPartition" aka the head aka "mainMem"
    smallestPartition->isFree = 0;
    globalAvailMemory-=request;
    //printf("%d", smallestPartition->startAdd);
    return smallestPartition->startAdd;
    /*
    //parse thru the linked list starting at the head until smallest size is found
    while (currentFree->next != NULL) {
        //printf("goes into loop");
        //check if next node is free, if used, skip
        if (currentFree->next->isFree == 1) {
            //printf("currentFree->next->size: '%d' \n smallestPartition->size '%d'"  , currentFree->next->size, smallestPartition->size);
            if (currentFree->next->size <= smallestPartition->size) {
                //check to see if the req fits
                if (currentFree->next->size >= request) {
                    smallestPartition = currentFree->next;
                }
            }       
        }
        //move to next node
        currentFree = currentFree -> next;     
    }

    if (getListSize(mainMem) == 1 && request <= currentFree->size/2) {
        //split node here
        //add new node
        addNode(currentFree->size/2+currentFree->startAdd, currentFree->endAdd, currentFree->size/2,currentFree->size/2+currentFree->startAdd, 1);
        //edit current node
        editNode(currentFree, currentFree->startAdd, currentFree->size/2+currentFree->startAdd, currentFree->size/2, currentFree->size/2+currentFree->startAdd, 1);
        
        currentFree = mainMem;
    }
    // //reset current to the smallest
    // currentFree = smallestPartition;
    //check if a split is needed: if (smallestPartition == power of 2 that is closest to request meaning keep spliting)
    while  ((currentFree->next != NULL) && request <= smallestPartition->size/2 && smallestPartition->size/2 >= MIN_MEM_CHUNK_SIZE) {
        // //check if next node is th e correct partition
        // if (currentFree->next->size == nextPowerOf2((unsigned) request)) {
        //     editNode(currentFree->next,currentFree->next->startAdd,currentFree->next->)
            
        // }
        // //if doesn't exist
        // if (currentFree->next == NULL) {
        //     //split: currentFree->size/2 and add new node to list of that size until partion is (just over the size) or (MIN_MEM_CHUNK_SIZE)
        // }
        //split node here
        //add new node
        addNode(smallestPartition->size/2+smallestPartition->startAdd, smallestPartition->endAdd, smallestPartition->size/2,smallestPartition->size/2+smallestPartition->startAdd, 1);
        //edit current node
        editNode(smallestPartition, smallestPartition->startAdd, smallestPartition->size/2+smallestPartition->startAdd, smallestPartition->size/2, smallestPartition->size/2+smallestPartition->startAdd, 1);
        //move to next node
        smallestPartition = mainMem;     
    }
    // found smallest, so copy it over to our workspace (currentFree)
    currentFree = smallestPartition;
    // current node is used
    currentFree->isFree = 0; 
    
    int temp = currentFree->startAdd + HEADER_SIZE;
    return temp;
    */
}

// Compute power of two greater than or equal to n
unsigned nextPowerOf2(unsigned n) {
    int power = MIN_MEM_CHUNK_SIZE;
    // base case
    if(n > power) {
        while(n > power) {
            power *= 2;
        }
    }
    
    return power;
}

int malloc_slab(int size) {
    return -1;
}



void free_buddy(void *ptr) {

    /*
        ~~~LOGIC~~~

        free node

        find buddy
        budNodeA, budNodeB :: A.address < b.address

        while(budNodeA && budNodeB are free) {
            join(budNodeA, budNodeB)
            budNodeB is our new updated node
            find new buddy and save in budNode A
        }

        
    */

    //printf("ptr - globalStartOfMemory = %d + %d = %d", ptr, globalStartOfMemory, ptr-globalStartOfMemory);
    // find the ptr given (startAdd) in our linked list using findNode() and storing it into a temp Node
    struct Node* temp = findNode(ptr-globalStartOfMemory-HEADER_SIZE);
    // 'free' the node by setting the node->isFree = 1
    temp->isFree = 1;
    globalAvailMemory+=temp->size;

    struct Node* lowerNode;
    struct Node* upperNode;

    // reset currentFree to head
    currentFree = mainMem;

    // find buddy node and set currentFree to it
    while(currentFree->next != NULL && currentFree->buddyNum == temp->buddyNum && currentFree->startAdd == temp->startAdd) {
        currentFree = currentFree->next;
    }

    // set upper and lower nodes
    if(currentFree->startAdd < temp->startAdd) {   
        lowerNode = currentFree;
        upperNode = temp;
    } else {
        lowerNode = temp;
        upperNode = currentFree;
    }

    // while buddy nodes are joinable, keep looping
    while(lowerNode->isFree == 1 && upperNode->isFree == 1) {

        // join nodes
        joinNodes(lowerNode, upperNode);

        // find buddy node and set currentFree to it
        currentFree = mainMem;      // reset currentFree to head
        while(currentFree->next != NULL && currentFree->buddyNum == upperNode->buddyNum && currentFree->startAdd == upperNode->startAdd) {
            currentFree = currentFree->next;
        }

        // set upper and lower nodes
        if(currentFree->startAdd < upperNode->startAdd) {   
            lowerNode = currentFree;
            upperNode = upperNode;
        } else {
            lowerNode = upperNode;
            upperNode = currentFree;
        }

    }

}
/*



    // start at the head node
    currentFree = mainMem;
    bool isJoiningPossible = false;
    // parse thru whole list to check if joining is possible
    while (currentFree->next != NULL) {
        // if both buddies are free meaning (cant find matching buddyNum)
        if (temp->buddyNum == currentFree->buddyNum && currentFree->startAdd != temp->startAdd && currentFree->isFree == 1) {
            // joining is possible
            isJoiningPossible = true;
        }
        currentFree = currentFree->next;
    }

    // loop while joining is possible
    while (isJoiningPossible) {
        // find the size and find what node is it's buddy (compare size and the buddyNums, make sure they are equal)
        // reset currentFree
        currentFree = mainMem;
        isJoiningPossible = false;

        while(currentFree->buddyNum != temp->buddyNum || currentFree->startAdd == temp->startAdd) {
            currentFree = currentFree->next;
        }   

        // currentFree will be looking at the other buddy at this point
        // buddy A = temp, buddy B = currentFree

        // Joining:
        //     find which buddy has a lower startAdd and set to buddy with the higher startAdd
        //      choose the buddy with he higher address as the edit and delete the lower address buddy
        
        
        //     find correct buddy number: parse thru oldBudNums array backwards (when value != -1), make it the new buddy number and change that number back to -1 in the list
        int updateBudNum;
        if(upperNode->oldBudNums[0] == -1) {    // no old buddyNums exist, set to -1;
            updateBudNum = -1;
        } else {                                // lowerNode->oldBudNum[i] = location of the last buddyNum on the array
            int i = 0;
            while(upperNode->oldBudNums[i] != -1) {
                i++;
            }
            updateBudNum = upperNode->oldBudNums[i-1];
            upperNode->oldBudNums[i-1] = -1;
        }
        
        //     editNode upper and deleteNode lower
        editNode(upperNode, lowerNode->startAdd, upperNode->size * 2, updateBudNum, 1);
        deleteNode(lowerNode);


        // check if joining is possible
        currentFree = mainMem;
        isJoiningPossible = false;
        // parse thru whole list to check if joining is possible
        while (currentFree->next != NULL) {
        // if both buddies are free meaning (cant find matching buddyNum)
            if (temp->buddyNum == currentFree->buddyNum && currentFree->startAdd != temp->startAdd && currentFree->isFree == 1) {
                // joining is possible
                isJoiningPossible = true;
            }
            currentFree = currentFree->next;
        }

    }
    
}
*/



void joinNodes(struct Node* lower, struct Node* upper) {
        
        //     find correct buddy number: parse thru oldBudNums array backwards (when value != -1), make it the new buddy number and change that number back to -1 in the list
        int updateBudNumU, updateBudNumL;
        int x;
        for(x = 0; x < 15; x++) {
            printf("LOWER_BUDDY_NUMS[%d]: %d\nUPPER_BUDDY_NUMS[%d]: %d\n", x, lower->oldBudNums[x], x, upper->oldBudNums[x]);
        }

        // upperNode->oldBudNum[i] = location of the last buddyNum on the array
        int i = 0;
        while(upper->oldBudNums[i] != -1) {
            i++;
        }
        updateBudNumU = upper->oldBudNums[i-1];
        upper->oldBudNums[i-1] = -1;
    

        // lowerNode->oldBudNum[i] = location of the last buddyNum on the array
        i = 0;
        while(lower->oldBudNums[i] != -1) {
            i++;
        }
        updateBudNumL = lower->oldBudNums[i-1];
        lower->oldBudNums[i-1] = -1;
        

        int tempReturn;
        if(updateBudNumU = -1) {
            tempReturn = updateBudNumL;
        } else {
            tempReturn = updateBudNumU;
        }
        //     editNode upper and deleteNode lower
        editNode(upper, lower->startAdd, upper->size * 2, tempReturn, 1);
        deleteNode(lower);
}

/*
void free_slab(void *ptr){
    
}
*/

void addNode(int start,/* int end, */int sz, int bud, int free) {
    // create node
    struct Node* temp = (struct Node*)malloc(sizeof(struct Node) * globalMemSize);

    temp->startAdd = start;
    //temp->endAdd = end;
    temp->size = sz;
    temp->buddyNum = bud;
    temp->isFree = free;
    int i;
    for(i = 0; i < 15; i++) {
        temp->oldBudNums[i] = -1;
    }
    temp->next = mainMem;
    mainMem = temp;
}

void editNode(struct Node* node, int start,/* int end, */int sz, int bud, int free) {
    node->startAdd = start;
    //node->endAdd = end;
    node->size = sz;
    node->buddyNum = bud;
    node->isFree = free;

}

int getListSize(struct Node* node) {
    int size = 1;
    while (node->next != NULL) {
        size++;
        node = node->next;
    }
    return size;
}

struct Node* findNode(int ID /*startAdd*/) {
    struct Node* temp = mainMem;
    while(temp != NULL) {
        if(temp->startAdd == ID) {
            // found
            return temp;
        }
        temp = temp->next;
    }
    // not found
    return NULL;
}

void deleteNode(struct Node* node) {

    // iterate through nodes. stop when 
    struct Node* temp = mainMem;

    // if deleting head node -> re-point mainMem to new head
    if(node->startAdd == 0) {
        mainMem = temp->next;
    } else {
        // iterate so temp->next points to node_to_delete
        while(temp->next->startAdd != node->startAdd) {
            temp = temp->next;
        }
        // point temp past node_to_delete
        temp->next = temp->next->next;
    }
        
    // clear node and unallocate node
    node->next=NULL;
    free(node);

}










