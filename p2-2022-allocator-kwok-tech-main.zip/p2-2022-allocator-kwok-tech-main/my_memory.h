#ifndef MY_MEMORY_H
#define MY_MEMORY_H

#include "interface.h"

// Declare your own data structures and functions here...

struct Node {
    int startAdd;           // starting address
    //int endAdd;             // ending address
    int size;               // mem_size
    int buddyNum;           // track buddy nodes    (filled size)
    int isFree;             // is this block used (0) or free (1)
    int oldBudNums[15];        // tracks old buddy numbers
    struct Node* next;
};


//global vars
int globalType;
int globalMemSize;
void* globalStartOfMemory;
int globalAvailMemory;

// list of mem
struct Node* mainMem;

// node trackers
struct Node* currentFree;

// Helper Functions
int malloc_buddy(int request);
unsigned nextPowerOf2(unsigned n);
int malloc_slab(int request);
void free_buddy(void *ptr);
void free_slab(void *ptr);

// Linked list functions
void addNode(int start,/* int end, */int sz, int bud, int free);
void editNode(struct Node* node, int start,/* int end, */int sz, int bud, int free);
int getListSize(struct Node* node);
struct Node* findNode(int ID /*startAdd*/);
void deleteNode(struct Node* node);
void joinNodes(struct Node* lower ,struct Node* upper);
#endif
