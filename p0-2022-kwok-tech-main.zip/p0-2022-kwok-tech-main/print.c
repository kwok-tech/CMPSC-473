#include <stdio.h>

extern unsigned long long var;

int main() {
	FILE *fp;
	fp = fopen("output.txt", "w");
	fprintf(fp, "%llu\n", var);
	fprintf(fp, "%llu\n", var);
	fclose(fp);
	return 0;
}
